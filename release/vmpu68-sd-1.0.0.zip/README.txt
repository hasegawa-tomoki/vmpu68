vmpu68 1.0.0 SD card image
=========================
1. Raspberry Pi Imager: "Use custom" でこの .img.xz を選び、SD カードに書き込む。
2. (任意) SD の wpa_supplicant.conf.example を wpa_supplicant.conf にコピーして SSID とパスフレーズを書く。
   あとから基板のシリアルコンソール(Pi の USB-C、115200)で  wifi <ssid> <passphrase>  でも書ける。
3. 基板に挿して電源 ON。初回起動は SD の vmpu68.vpk から FPGA に自動で書き込む(約 1〜2 分、Pi 本体の ACT LED が速く点滅。基板の RGB LED は消灯)。
   終わると再起動して X68000 が動き出す。SRAM の起動画面プログラムも自動で入る(vmpu68.cfg の sramboot=1)。
4. 復旧したいときも同じ手順で焼き直せばよい(FPGA は毎回書き直される。Wi-Fi の設定は消えるので再度書く)。
   初回書込みに失敗すると SD に provision.failed ができて次回は再試行しない。消せばもう一度試す。
Web UI: http://<基板の IP>/  コンソール: wifi / upd / fpga / rm / st など
